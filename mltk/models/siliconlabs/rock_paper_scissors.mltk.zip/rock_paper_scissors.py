__mltk_version__ = '0.6.0'

"""rock_paper_scissors
*************************

- Source code: `rock_paper_scissors.py <https://github.com/siliconlabs/mltk/blob/master/mltk/models/siliconlabs/rock_paper_scissors.py>`_.
- Pre-trained model: `rock_paper_scissors.mltk.zip <https://github.com/siliconlabs/mltk/blob/master/mltk/models/siliconlabs/rock_paper_scissors.mltk.zip>`_.

This provides an example of how to define a classification model 
that uses the Rock/Paper/Scissors dataset with the ParallelImageGenerator as its data source.

The basic flow for the ML model is:

``96x96x1 grayscale image of hand gesture -> ML Model -> [result vector]``


Where `[result vector]` is a 3 element array with each element containing the % probability that the 
given image is a "rock", "paper", "scissor", or _unknown_ hand gesture.



Commands
--------------

.. code-block:: shell

   # Do a "dry run" test training of the model
   mltk train rock_paper_scissors-test

   # Train the model
   mltk train rock_paper_scissors

   # Evaluate the trained model .tflite model
   mltk evaluate rock_paper_scissors --tflite

   # Profile the model in the MVP hardware accelerator simulator
   mltk profile rock_paper_scissors --accelerator MVP

   # Profile the model on a physical development board
   mltk profile rock_paper_scissors --accelerator MVP --device

   # Dump some of the augmented images
   mltk custom rock_paper_scissors dump --count 100

   # Run this model in the image classifier application
   mltk classify_image rock_paper_scissors --dump-images

Model Summary
--------------

.. code-block:: shell
    
    mltk summarize rock_paper_scissors --tflite
    
    +-------+-----------------+-------------------+-----------------+-----------------------------------------------------+
    | Index | OpCode          | Input(s)          | Output(s)       | Config                                              |
    +-------+-----------------+-------------------+-----------------+-----------------------------------------------------+
    | 0     | quantize        | 84x84x1 (float32) | 84x84x1 (int8)  | BuiltinOptionsType=0                                |
    | 1     | conv_2d         | 84x84x1 (int8)    | 82x82x16 (int8) | Padding:valid stride:1x1 activation:relu            |
    |       |                 | 3x3x1 (int8)      |                 |                                                     |
    |       |                 | 16 (int32)        |                 |                                                     |
    | 2     | max_pool_2d     | 82x82x16 (int8)   | 41x41x16 (int8) | Padding:valid stride:2x2 filter:2x2 activation:none |
    | 3     | conv_2d         | 41x41x16 (int8)   | 39x39x16 (int8) | Padding:valid stride:1x1 activation:relu            |
    |       |                 | 3x3x16 (int8)     |                 |                                                     |
    |       |                 | 16 (int32)        |                 |                                                     |
    | 4     | max_pool_2d     | 39x39x16 (int8)   | 19x19x16 (int8) | Padding:valid stride:2x2 filter:2x2 activation:none |
    | 5     | conv_2d         | 19x19x16 (int8)   | 17x17x32 (int8) | Padding:valid stride:1x1 activation:relu            |
    |       |                 | 3x3x16 (int8)     |                 |                                                     |
    |       |                 | 32 (int32)        |                 |                                                     |
    | 6     | max_pool_2d     | 17x17x32 (int8)   | 8x8x32 (int8)   | Padding:valid stride:2x2 filter:2x2 activation:none |
    | 7     | reshape         | 8x8x32 (int8)     | 2048 (int8)     | BuiltinOptionsType=0                                |
    |       |                 | 2 (int32)         |                 |                                                     |
    | 8     | fully_connected | 2048 (int8)       | 32 (int8)       | Activation:relu                                     |
    |       |                 | 2048 (int8)       |                 |                                                     |
    |       |                 | 32 (int32)        |                 |                                                     |
    | 9     | fully_connected | 32 (int8)         | 4 (int8)        | Activation:none                                     |
    |       |                 | 32 (int8)         |                 |                                                     |
    |       |                 | 4 (int32)         |                 |                                                     |
    | 10    | softmax         | 4 (int8)          | 4 (int8)        | BuiltinOptionsType=9                                |
    | 11    | dequantize      | 4 (int8)          | 4 (float32)     | BuiltinOptionsType=0                                |
    +-------+-----------------+-------------------+-----------------+-----------------------------------------------------+
    Total MACs: 5.870 M
    Total OPs: 12.050 M
    Name: rock_paper_scissors
    Version: 1
    Description: Image classifier example for detecting Rock/Paper/Scissors hand gestures in images
    Classes: rock, paper, scissor, _unknown_
    hash: 9b557f35e32df7614723ddaafd77d75f
    date: 2022-05-02T23:18:20.997Z
    runtime_memory_size: 137176
    detection_threshold: 175
    average_window_duration_ms: 500
    minimum_count: 2
    suppression_count: 1
    samplewise_norm.rescale: 0.0
    samplewise_norm.mean_and_std: True
    .tflite file size: 80.2kB


Model Diagram
------------------

.. code-block:: shell
   
   mltk view  rock_paper_scissors --tflite

.. raw:: html

    <div class="model-diagram">
        <a href="../../../../_images/models/ rock_paper_scissors.tflite.png" target="_blank">
            <img src="../../../../_images/models/ rock_paper_scissors.tflite.png" />
            <p>Click to enlarge</p>
        </a>
    </div>

"""

# Bring in the required Keras classes
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Flatten, Dropout, BatchNormalization
from tensorflow.keras.layers import Conv2D, MaxPooling2D

from mltk.core.model import (
    MltkModel,
    TrainMixin,
    ImageDatasetMixin,
    EvaluateClassifierMixin
)

# By default, we use the ParallelImageDataGenerator
# We could use the Keras ImageDataGenerator but it is slower
from mltk.core.preprocess.image.parallel_generator import ParallelImageDataGenerator
#from keras.preprocessing.image import ImageDataGenerator
# Import the dataset
from mltk.datasets.image import rock_paper_scissors_v2


# Instantiate the MltkModel object with the following 'mixins':
# - TrainMixin            - Provides classifier model training operations and settings
# - ImageDatasetMixin     - Provides image data generation operations and settings
# - EvaluateClassifierMixin         - Provides classifier evaluation operations and settings
# @mltk_model # NOTE: This tag is required for this model be discoverable
class MyModel(
    MltkModel, 
    TrainMixin, 
    ImageDatasetMixin, 
    EvaluateClassifierMixin
):
    pass
my_model = MyModel()


#################################################
# General Settings
# 
my_model.version = 1
my_model.description = 'Image classifier example for detecting Rock/Paper/Scissors hand gestures in images'


#################################################
# Training Settings
my_model.epochs = 125
my_model.batch_size = 32
my_model.optimizer = 'adam'
my_model.metrics = ['accuracy']
my_model.loss = 'categorical_crossentropy'

#################################################
# Training callback Settings

# Generate a training weights .h5 whenever the 
# val_accuracy improves
my_model.checkpoint['monitor'] =  'val_accuracy'


# https://keras.io/api/callbacks/reduce_lr_on_plateau/
# If the test loss doesn't improve after 'patience' epochs 
# then decrease the learning rate by 'factor'
my_model.reduce_lr_on_plateau = dict(
  monitor='loss',
  factor = 0.95,
  min_delta=0.001,
  patience = 1
)

# If the validation accuracy doesn't improve after 35 epochs then stop training
# https://keras.io/api/callbacks/early_stopping/
my_model.early_stopping = dict( 
  monitor = 'accuracy',
  patience = 25,
  verbose=1
)




#################################################
# TF-Lite converter settings
my_model.tflite_converter['optimizations'] = ['DEFAULT']
my_model.tflite_converter['supported_ops'] = ['TFLITE_BUILTINS_INT8']
my_model.tflite_converter['inference_input_type'] = 'float32'
my_model.tflite_converter['inference_output_type'] = 'float32'
 # generate a representative dataset from the validation data
my_model.tflite_converter['representative_dataset'] = 'generate'



#################################################
# Image Dataset Settings

# The directory of the training data
# NOTE: This can also be a directory path
my_model.dataset = rock_paper_scissors_v2
# The classification type
my_model.class_mode = 'categorical'
# The class labels found in your training dataset directory
my_model.classes = rock_paper_scissors_v2.CLASSES
# The input shape to the model. The dataset samples will be resized if necessary
my_model.input_shape = (84,84,1)
# Shuffle the dataset directory once
my_model.shuffle_dataset_enabled = True

# The numbers of samples for each class is different
# Then ensures each class contributes equally to training the model
my_model.class_weights = 'balanced'


# These are parameters used by the image_classifier application
# They may be overridden by specifying similar options to the command:
# mltk classify_image rock_paper_scissors 
my_model.model_parameters['detection_threshold'] = 175 
my_model.model_parameters['average_window_duration_ms'] = 500 
my_model.model_parameters['minimum_count'] = 2 
my_model.model_parameters['suppression_count'] = 1 


#################################################
# ParallelImageDataGenerator Settings

my_model.datagen = ParallelImageDataGenerator(
    cores=0.65,
    debug=False,
    max_batches_pending=32, 
    validation_split= 0.15,
    validation_augmentation_enabled=False,
    rotation_range=15,
    width_shift_range=5,
    height_shift_range=5,
    brightness_range=(0.80, 1.10),
    contrast_range=(0.80, 1.10),
    noise=['gauss', 'poisson', 's&p'],
    zoom_range=(0.95, 1.05),
    samplewise_center=True,
    samplewise_std_normalization=True,
    rescale=None,
    horizontal_flip=True,
    vertical_flip=True,
)


#################################################
# Build the ML Model
def my_model_builder(my_model: MyModel):
    model = Sequential()

    filter_count = 16

    model.add(Conv2D(filter_count, (3, 3), input_shape=my_model.input_shape))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))

    model.add(Conv2D(filter_count, (3, 3)))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))

    model.add(Conv2D(filter_count*2, (3, 3)))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))

    model.add(Flatten())  # this converts our 3D feature maps to 1D feature vectors
    model.add(Dense(filter_count*2)) # This should be the same size at the previous Conv2D layer count
    model.add(Activation('relu'))
    model.add(Dropout(0.5))
    model.add(Dense(my_model.n_classes, activation='softmax'))

    model.compile(
        loss=my_model.loss, 
        optimizer=my_model.optimizer, 
        metrics=my_model.metrics
    )

    return model

my_model.build_model_function = my_model_builder




# Register the "dump" custom command
import typer
@my_model.cli.command('dump')
def dump_custom_command(
    count:int = typer.Option(100, '--count',
        help='Number of samples to dump'
    ),
):
    """Custom command to dump the augmented samples
    
    \b
    Invoke this command with:
    mltk custom rock_paper_scissors dump --count 20
    """

    my_model.datagen.save_to_dir = my_model.create_log_dir('dump', delete_existing=True)
    my_model.datagen.debug = True
    my_model.datagen.cores = 1
    my_model.datagen.max_batches_pending = 1
    my_model.datagen.batch_size = 1

    my_model.load_dataset(subset='training')

    for i, _ in enumerate(my_model.x):
        if i >= count:
            break
    
    my_model.unload_dataset()

    print(f'Generated data dump to: {my_model.datagen.save_to_dir}')